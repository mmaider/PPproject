import sys
from PyQt5 import uic
from PyQt5.QtWidgets import QApplication, QMainWindow, QFileDialog, QTableWidgetItem, QInputDialog
from PyQt5.QtGui import QPixmap
import sqlite3
import random


class MainWindow(QMainWindow):
    def __init__(self):
        super().__init__()
        self.load_main()

    def load_main(self):
        uic.loadUi('planktonprojectmain.ui', self)
        self.initUI()

    def initUI(self):
        self.setGeometry(60, 60, 490, 505)
        self.setWindowTitle('PlanktonProject')
        self.aboutus.clicked.connect(self.openaboutus)
        self.vacancys.clicked.connect(self.openvacancys)
        self.resumes.clicked.connect(self.openresume)
        self.anothervacancy.clicked.connect(self.createvacancys)
        self.anotherresume.clicked.connect(self.createresume)
        self.filename = ''
        self.start = ''

    def openaboutus(self):
        uic.loadUi('planktonprojectaboutus.ui', self)
        self.setWindowTitle('PlanktonProject')
        self.pushButton.clicked.connect(self.load_main)
        con = sqlite3.connect('PlanctonProject.db')
        cur = con.cursor()
        id_vacancy = cur.execute("Select MAX(id) AS mid from vacancy").fetchall()[0][0]
        id_resumes = cur.execute("Select MAX(id) AS mid from resumes").fetchall()[0][0]
        self.label_2.setText(self.label_2.text() + (
            '\nНа данный момент у нас зарегестрировано порядка {} вакансий и {} резюме!'
            '\nУдачи, коллеги!'.format(id_vacancy, id_resumes)))
        con.commit()

    def openvacancys(self):
        uic.loadUi('planktonprojectallvacancy.ui', self)
        self.setWindowTitle('PlanktonProject')
        self.pushButton.clicked.connect(self.load_main)

        cur = sqlite3.connect('PlanctonProject.db')
        result = [cur.execute("Select * from vacancy").fetchall()][0]
        self.tableWidget.setRowCount(len(result))
        self.tableWidget.setColumnCount(len(result[0]) - 1)
        self.titles = ['Компания', 'Email', 'Специализация', 'Опыт работы', 'Навыки', 'Зарплата',
                       'Метро', 'Описание']
        self.tableWidget.setHorizontalHeaderLabels(self.titles)
        for i, elem in enumerate(result):
            for j, val in enumerate(elem[1::]):
                self.tableWidget.setItem(i, j, QTableWidgetItem(str(val)))

    def openresume(self):
        uic.loadUi('planktonprojectallrezume.ui', self)
        self.setWindowTitle('PlanktonProject')
        self.pushButton.clicked.connect(self.load_main)

        cur = sqlite3.connect('PlanctonProject.db')
        result = [cur.execute("Select * from resumes").fetchall()][0]
        self.tableWidget.setRowCount(len(result))
        self.tableWidget.setColumnCount(len(result[0]) - 1)
        self.titles = ['ФИО', 'Email', 'Специализация', 'Опыт работы', 'Описание', 'Аватарка']
        self.tableWidget.setHorizontalHeaderLabels(self.titles)
        for i, elem in enumerate(result):
            for j, val in enumerate(elem[1::]):
                if val == None or val == 'None':
                    self.tableWidget.setItem(i, j, QTableWidgetItem('Нет'))
                else:
                    self.tableWidget.setItem(i, j, QTableWidgetItem(str(val)))

    def createvacancys(self):
        uic.loadUi('planktonprojectcreatevacancy.ui', self)
        self.setWindowTitle('PlanktonProject')
        self.pushButton_9.clicked.connect(self.kapcha_vacancy)
        self.pushButton_10.clicked.connect(self.load_main)

    def createresume(self):
        uic.loadUi('planktonprojectcreaterezume.ui', self)
        self.setWindowTitle('PlanktonProject')
        self.pushButton_9.clicked.connect(self.kapcha_resume)
        self.pushButton_10.clicked.connect(self.chosefile)
        self.pushButton_11.clicked.connect(self.load_main)

    def getvacancy(self):
        company = self.NameEdit.text()
        email = self.lineEdit_4.text()
        exp = self.spinBox.value()
        skills = self.textEdit.toPlainText()
        salary = self.lineEdit.text()
        metro = self.lineEdit_2.text()
        info = self.textEdit_2.toPlainText()
        arr = [self.radioButton, self.radioButton_2, self.radioButton_3, self.radioButton_4, self.radioButton_5,
               self.radioButton_6, self.radioButton_7, self.radioButton_8, self.radioButton_9, self.radioButton_10,
               self.radioButton_11]
        specialization = ''
        for i in arr:
            if i.isChecked():
                specialization = i.text()
                break

        con = sqlite3.connect('PlanctonProject.db')
        cur = con.cursor()
        idd = [cur.execute("Select MAX(id) AS mid from vacancy").fetchall()[0][0]]
        idd = idd[0] + 1
        arr1 = ', '.join(
            [str(idd), '"' + company + '"', '"' + email + '"', '"' + specialization + '"',
             '"Не менее ' + str(exp) + ' лет"',
             '"' + skills + '"',
             salary, '"' + metro + '"', '"' + info + '"'])
        a = "INSERT INTO vacancy VALUES(" + arr1 + ")"
        cur.execute(a)
        con.commit()
        self.load_main()

    def getresume(self):
        namer = self.NameEdit.text()
        surname = self.SurnameEdit.text()
        otchestvo = self.lineEdit_3.text()
        email = self.lineEdit_4.text()
        exp = self.spinBox.value()
        info = self.textEdit.toPlainText()
        arr = [self.radioButton, self.radioButton_2, self.radioButton_3, self.radioButton_4, self.radioButton_5,
               self.radioButton_6, self.radioButton_7, self.radioButton_8, self.radioButton_9, self.radioButton_10,
               self.radioButton_11]
        specialization = ''
        for i in arr:
            if i.isChecked():
                specialization = i.text()
                break

        con = sqlite3.connect('PlanctonProject.db')
        cur = con.cursor()
        idd = [cur.execute("Select MAX(id) AS mid from resumes").fetchall()[0][0]]
        idd = idd[0] + 1
        arr1 = ', '.join(
            [str(idd), '"' + surname + ' ' + namer + ' ' + otchestvo + '"', '"' + email + '"',
             '"' + specialization + '"', '"Не менее ' + str(exp) + ' лет"', '"' + info + '"',
             '"' + self.photoname.text() + '"'])
        a = "INSERT INTO resumes VALUES(" + arr1 + ")"
        cur.execute(a)
        con.commit()
        self.load_main()

    def chosefile(self):
        a = QFileDialog.getOpenFileName()[0].split('/')[-1]
        self.filename = a
        self.start = a
        self.pixmap = QPixmap(self.filename).scaledToWidth(121).scaledToHeight(121)
        self.photoname_2.setPixmap(self.pixmap)
        self.photoname.setText(self.filename)

    def kapcha_resume(self):
        operations = '+-'
        quote = str(random.randint(1, 100)) + operations[random.randint(0, 1)] + str(random.randint(1, 100))

        i, okBtnPressed = QInputDialog.getText(self, "Капча",
                                               "Для отправки решите пример, чтобы мы знали, "
                                               "что вы не робот :)\n" + quote)
        if okBtnPressed:
            if int(i) == eval(quote):
                self.getresume()

    def kapcha_vacancy(self):
        operations = 'abcdefghijklmnopqrstuvwxyz'
        number = random.randint(1, 5)
        quote = ''
        for i in range(5):
            quote += operations[random.randint(0, 25)]
        i, okBtnPressed = QInputDialog.getText(self, "Капча", "Для отправки напишите"
                                                              " {} букву кода {} :)\n".format(number, quote))
        if okBtnPressed:
            if quote[number - 1] == i:
                self.getvacancy()


if __name__ == '__main__':
    app = QApplication(sys.argv)
    ex = MainWindow()
    ex.show()
    sys.exit(app.exec())
